export type UserBalanceData = {
  userBalanceId: number;
  userId: number;
  trainingId: number;
  trainingQtt: number;
};
