export type UserFriendData = {
  userFriendId?: number;
  userId?: number;
  friendId?: number;
};
