export type TokenData = {
  accessToken: string;
  refreshToken: string;
};
